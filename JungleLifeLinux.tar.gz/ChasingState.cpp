﻿#include "ChasingState.h"

ChasingState::ChasingState(AnimalStateSubject *subject) : AnimalState(subject)
{

}

void ChasingState::advance(int phase)
{

}
