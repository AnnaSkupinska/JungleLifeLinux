#include "Configuration.h"

Configuration::Configuration()
{

}
