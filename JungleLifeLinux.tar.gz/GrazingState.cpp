﻿#include "GrazingState.h"

GrazingState::GrazingState(AnimalStateSubject *subject) : AnimalState(subject)
{

}

void GrazingState::advance(int phase)
{
  // TODO: zaimplementować
}
