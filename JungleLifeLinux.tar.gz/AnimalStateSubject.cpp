#include "AnimalStateSubject.h"

AnimalStateSubject::AnimalStateSubject()
{

}
