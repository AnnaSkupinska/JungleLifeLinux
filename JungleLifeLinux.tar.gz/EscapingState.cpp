﻿#include "EscapingState.h"

EscapingState::EscapingState(AnimalStateSubject *subject) : AnimalState(subject)
{

}

void EscapingState::advance()
{

}
