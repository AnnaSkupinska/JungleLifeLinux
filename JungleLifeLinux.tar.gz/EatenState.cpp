﻿#include "EatenState.h"

EatenState::EatenState(AnimalStateSubject *subject) : AnimalState(subject)
{

}

void EatenState::advance()
{

}
