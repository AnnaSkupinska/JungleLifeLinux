﻿#include "AnimalState.h"

AnimalState::AnimalState(AnimalStateSubject* subject) : subject(subject)
{

}
