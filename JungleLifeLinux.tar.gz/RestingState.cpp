﻿#include "RestingState.h"

RestingState::RestingState(AnimalStateSubject *subject) : AnimalState(subject)
{

}

void RestingState::advance()
{

}
