﻿#ifndef STATISTICNAMES_H
#define STATISTICNAMES_H

#include <string>



#endif // STATISTICNAMES_H
