﻿#include "Organism.h"

Organism::Organism()
{

}
