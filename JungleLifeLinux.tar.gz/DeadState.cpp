﻿#include "DeadState.h"

DeadState::DeadState(AnimalStateSubject *subject) : AnimalState(subject)
{

}

void DeadState::advance(int phase)
{

}
